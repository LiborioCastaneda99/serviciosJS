<!doctype html>
<html lang="es">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script src="/assets/js/base.js"></script>

    <title>Prueba de servicios JS</title>
</head>
<body>

    <div class="jumbotron jumbotron-fluid container p-4 mt-3" style="border-radius:10px;">
        <div class="container">
            <h1 class="display-4 text-center">Probando Servicios JS <br>Login</h1>
            <hr class="my-4">
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb bg-dark">
                <li class="breadcrumb-item active" aria-current="page" style="color: white;">Inicio</li>
            </ol>
        </nav>
        <hr class="my-4">
        <div class="row">
            <div class="col-md-12">
                <a href="operaciones.php" class="btn btn-success w-100">Realizar Operaciones</a>
            </div>
        </div>
        <hr class="my-4">
        <div class="row">
            <div class="col-md-6" style="margin:0px auto;">
                <label for="">Usuario</label>
                <input type="text" name="user" req id="user" class="form form-control" required="">
            </div>

            <div class="col-md-6" style="margin:0px auto;">
                <label for="">Password</label>
                <input type="password" name="pass" id="pass" class="form form-control" required="">
            </div>

            <div class="col-md-6" style="margin:0px auto;">
                <br>
                <div class="col-md-4">
                    <input type="hidden" value="1" id="op" name="op"  class="form form-control">
                </div>
                <input type="submit" name="sub" value="Enviar" class="btn btn-warning w-100" onclick="test();" >
            </div>
        </div>

        <div id="texto_nav1" class="text-center"></div>

        <div id="respuesta" class="mt-3"></div>

    </div>
</div>

<!-- Optional JavaScript; choose one of the two! -->

<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

<!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>-->
</body>
</html>
<?php

//const CLASES = $_SERVER['DOCUMENT_ROOT'] . '/class';
require_once ($_SERVER['DOCUMENT_ROOT'] . '/class/Service.php');

use classes\Service;

$service = new Service('ProbrandoServicio'); // Reemplazar

$op = trim(addslashes($_POST['op']));

error_log ("OP: ".$op);

if ($op) {
    //Obtener datos del post
    $data = $_POST;
    $paso = true;
    $t = '';

    //Verificar que la opción exista.
    switch ($op) {
        case '1':
            $t = 'ejemplo';
            error_log ("entra al switch en ajxBase");
            break;
            
        case '2':
            $t = 'suma';
            error_log ("entra al switch en suma:  ");
            break;
        default:
            $paso = false;
            $resp = ['error' => 1, 'mensaje' => 'Opción incorrecta.'];      
                    error_log("incorrecta");      
            break;
    }
    
    //Validar opción elegida
    if ($paso) {
        $data['t'] = $t;
        // $data['token'] = $token;
        // $data['usuario'] = $usuario;
        $resp = $service->useService($data);

    } else {
        $resp = ['error' => 1, 'mensaje' => 'Opción incorrecta.'];
    }

    //Retorno de datos al js
    echo json_encode($resp);

} else {
    echo json_encode(['error' => 1, 'mensaje' => 'Opción incorrecta.']);
}



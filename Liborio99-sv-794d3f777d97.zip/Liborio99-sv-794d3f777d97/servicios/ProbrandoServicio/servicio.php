<?php


require_once $_SERVER['DOCUMENT_ROOT'] . '/class/Validaciones.php';

$val = new Validaciones();

$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'OPTIONS') {
    response('services', 'Error servicio', [], 1);
} else if ($method !== 'POST') {
    response('services', 'Allow: POST', [], 1);
} else {
    $token = empty($_POST['token']) ? '' : trim(addslashes($_POST['token']));

    $t=$_POST['t'];

    switch ($_POST['t']) {

        case "ejemplo": // Ejemplo
            
            $user = isset($_POST["user"]) ? $_POST["user"] : 0;
            $pass = isset($_POST["pass"]) ? $_POST["pass"] : 0;

            $validar_user = $val->validacion('string', 'user', $user, true);
            $validar_pass = $val->validacion('string', 'pass', $pass, true);

            if ($validar_user['estado'] != 1) {
                response($validar_user['mensaje'], [], 1);
            } elseif ($validar_pass['estado'] != 1) {
                response($validar_pass['mensaje'], [], 1);
            } else {
                $modulo = "Prueba"; // Indicador del módulo que se está ejecutando
                $mensaje = "Se ha ejecuado el servicio";
                $datos = [ "campo" => $user, "password" =>$pass ]; // Respuesta / resultado de la operación
                $error = 0; // Indicador de error

                response($modulo, $mensaje, $datos, $error);
            }

            error_log ("listo entro al servicio de ".$t.": ".$modulo. " - ".$mensaje." - ".$datos['campo']." - ".$datos['password']." - ".$error);

            break;


            case "suma":
  
                $numeroUno = isset($_POST["numeroUno"]) ? $_POST["numeroUno"] : 0;
                $numeroDos = isset($_POST["numeroDos"]) ? $_POST["numeroDos"] : 0;

                /*$numeroUno=2;
                $numeroDos=5;*/
             
                $vSuma=$numeroUno+$numeroDos;
                $vMultiplicacion=$numeroUno*$numeroDos;
                $vResta=$numeroUno-$numeroDos;
                $vDivision=$numeroUno/$numeroDos;


                $modulo = "Suma"; // Indicador del módulo que se está ejecutando
                $mensaje = "Se ha ejecuado el servicio";
                $datos = [ "suma" => $vSuma, "multiplicacion" => $vMultiplicacion,  "division" => $vDivision,  "resta" => $vResta]; // Respuesta / resultado de la operación
                $error = 0; // Indicador de error

                response($modulo, $mensaje, $datos, $error);

                error_log ("listo entro al servicio de ".$t.": ".$modulo. " - ".$mensaje." - ".$datos["suma"]." - ".$datos["multiplicacion"]." - ".$datos["division"]." - ".$datos["resta"]." - ".$error);

                break;

        case "":
            error_log ("no entro al servicio");

            break;

        default:
            response('services', 'Error, esta opción no existe.', [], 1);
            break;
    }
}


/**
 * Respuesta
 * @param string $modulo
 * @param string $mensaje
 * @param string $datos
 * @param int $error
 */
function response($modulo, $mensaje, $datos, $error)
{
    header("HTTP/1.1 " . $error == 0 ? 200 : 500);

    $response['error'] = $error;
    $response['mensaje'] = $mensaje;
    $response['modulo'] = $modulo;
    $response['datos'] = $datos;

    $json_response = json_encode($response);

    /* $method = $_SERVER['REQUEST_METHOD'];
    $tipo = $_POST["t"];
    $request = json_encode($_POST); */

    echo $json_response;
}
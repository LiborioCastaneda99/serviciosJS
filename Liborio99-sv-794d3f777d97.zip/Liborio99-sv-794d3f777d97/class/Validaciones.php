<?php

/**
 * Created by PhpStorm.
 * User: Sergio-PC
 * Date: 31/01/2018
 * Time: 10:20 AM
 */
class Validaciones
{
    public function __construct()
    {

    }

    /**
     * @param $tipo
     * @param $campo
     * @param $valor
     * @param bool $obligatorio
     */
    public function validacion($tipo, $campo, $valor, $obligatorio = true)
    {
        $tipo = trim($tipo);
        $campo = mb_strtoupper(trim($campo));
        $valor = trim($valor);
        $resultado = ['estado' => 1, 'mensaje' => 'OK'];

        if ($valor == "" and $obligatorio) {
            $resultado['estado'] = 2;
            $resultado['mensaje'] = ("El campo $campo no puede ser vacío.");

        } else {
            switch ($tipo) {
                case "int":

                    if (!ctype_digit($valor)) {
                        $resultado['estado'] = 2;
                        $resultado['mensaje'] = "El campo $campo debe ser entero.";
                    }

                break;

                case "double":

                    if (!is_numeric($valor)) {
                        $resultado['estado'] = 2;
                        $resultado['mensaje'] = "El campo $campo debe ser un digito.";
                    }

                break;

                case 'string':

                    if (!is_string($valor)) {
                        $resultado['estado'] = 2;
                        $resultado['mensaje'] = "El campo $campo debe ser un digito.";
                    }
                    
                break;
            }
        }

        return $resultado;
    }

}

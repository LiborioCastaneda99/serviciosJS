
class Suma {
    constructor (numeroUno, numeroDos) {
      this.numeroUno = numeroUno;
      this.numeroDos = numeroDos;
    }

    // Getter
    get opSuma() {
       return this.calcSuma();
     }
     
    // Método
    calcSuma () {
      return this.numeroUno + this.numeroDos;
    }
  }
  
  const totalSuma = new Suma(50, 10);
  
  
    var objetivo = document.getElementById('demo');
    objetivo.innerHTML = (totalSuma.opSuma);

function test() {
   
    var vOp=document.getElementById('op').value;
    var vUser=document.getElementById('user').value;
    var vPass=document.getElementById('pass').value;

    //var objetivo = document.getElementById('texto_nav1');
    //objetivo.innerHTML = vUser +" -- "+ vPass +" -- " + vOp;

    if (vUser=='') {
        swal({
            icon: 'warning',
            title: 'El campo está vacío',
            text: 'Faltó valor en el nombre de usuario!',
        });
        return 0;
    }

    if (vPass=='') {
        swal({
            icon: 'warning',
            title: 'El campo está vacío',
            text: 'Faltó valor en la contraseña!',
        });
        return 0;
    }
    
    let data = {
        op: vOp,
        user: vUser,
        pass: vPass,
    };

    $.ajax({
        url: '../ajax/ajxBase.php', // Reemplazar nombre
        type: 'POST',
        data,
        dataType: 'json',
        success: function (resp) {
            if (!resp.error){
                swal({
                    icon: 'success',
                    title: 'Enviado...',
                    text: 'Se ha enviado correctamente!',
                });

                respuesta.innerHTML = `
                <div class="alert alert-primary" role="alert">
                <p> <b>Datos ingresados.</b></p>
                <p><b> Usuario:  </b>${vUser}</p>
                <p><b> Contraseña:  </b>${vPass}</p>
                </div>
                `
            } else {
                swal({
                    icon: 'error',
                    title: 'Es una opción invalida.',
                    text: 'Por favor digite nuevamente una opción valida!',
                })
            }
        }
    });
}


function operaciones() {
   
    var vOp=document.getElementById('op').value;
    var vUno=document.getElementById('numeroUno').value;
    var vDos=document.getElementById('numeroDos').value;

    //var objetivo = document.getElementById('texto_nav1');
    //objetivo.innerHTML = vUser +" -- "+ vPass +" -- " + vOp;

    if (vUno=='') {
        swal({
            icon: 'warning',
            title: 'El campo está vacío',
            text: 'Faltó valor en el numero 1!',
        });
        return 0;
    }

    if (vDos=='') {
        swal({
            icon: 'warning',
            title: 'El campo está vacío',
            text: 'Faltó valor en el numero 2!',
        });
        return 0;
    }

    
    let data = {
        op: vOp,
        numeroUno: vUno,
        numeroDos: vDos,
    };

    $.ajax({
        url: '../ajax/ajxBase.php', // Reemplazar nombre
        type: 'POST',
        data,
        dataType: 'json',
        success: function (resp) {
            if (!resp.error){
                
                swal({
                    icon: 'success',
                    title: 'Enviado...',
                    text: 'Se ha enviado correctamente!',
                });

                respuesta.innerHTML = `
                <div class="alert alert-primary" role="alert">
                <p> <b>Datos ingresados.</b></p>
                <p><b> Numero 1:  </b>${vUno}<br>
                <b> Numero 2:  </b>${vDos}</p>
                <hr class="my-4">
                <p> <b>Resultado de las operaciones.</b></p>
                <p><b> Suma:  </b>${resp.datos.suma}<br>
                <b> Resta:  </b>${resp.datos.resta}<br>
                <b> Multiplicación:  </b>${resp.datos.multiplicacion}<br>
                <b> División:  </b>${resp.datos.division}
                </p>
                </div>
                `
            } else {
                swal({
                    icon: 'error',
                    title: 'Es una opción invalida.',
                    text: 'Por favor digite nuevamente una opción valida!',
                })
            }
        }
    });
}